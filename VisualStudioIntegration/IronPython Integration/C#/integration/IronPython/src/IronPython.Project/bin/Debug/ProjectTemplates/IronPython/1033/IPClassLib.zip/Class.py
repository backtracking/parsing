class $safeitemname$:
    "Description of Class"